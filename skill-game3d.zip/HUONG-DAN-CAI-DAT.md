# Hướng dẫn cài skill game3d

Skill dựng web game 3D (Three.js + Socket.IO nhiều người chơi) với hệ phong cách
ĐÁNH SỐ: nhân vật NV-01..NV-10, ngoại cảnh NC-01..NC-07, biến thể TG/TT/M, combo CB-01..05.

## Cài đặt
1. Giải nén gói zip này.
2. Chép thư mục `game3d` vào `~/workspace/custom-skills/` của Muse
   (đường dẫn cuối: `~/workspace/custom-skills/game3d/SKILL.md`).
3. Xong — gọi bằng mã số, ví dụ: "tạo game 3D phong cách NV-05 + NC-06",
   "đổi game sang CB-02", "thêm biến thể TG-4 đêm trăng".

## Nội dung gói
- `game3d/SKILL.md` — 4 bảng phong cách đánh số + kiến trúc chuẩn + quy tắc cứng + deploy.
- `game3d/skill.yaml` — metadata skill.
- `game3d/reference/styles.json` — bảng máy đọc được (NV/NC/biến thể/combo).

## Mặc định
- Game mô phỏng làng quê/xã hội: CB-01 (NV-01 + NC-01 + TG-2 + TT-1 + M-2) — mô phỏng 3D chân thật.
- Game cho trẻ nhỏ: CB-02 (chibi + pastel).

© By Hoang Kim Long - Email: tonyhoang.oliver@gmail.com
